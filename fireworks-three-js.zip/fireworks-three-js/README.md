# Fireworks Three.js

Siraj Mughal and Imaan Bajwa

How to run code:
-extract the zip file
-run "python server.py" in the terminal once you open the extracted file in an IDE
-click on the link and then click on dist/ to see the demo

